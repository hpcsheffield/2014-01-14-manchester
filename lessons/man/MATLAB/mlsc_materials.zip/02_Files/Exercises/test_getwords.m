function tests = test_getwords

tests = functiontests( localfunctions() );

end

function setupOnce(testCase) %#ok<*DEFNU>

end

function test_IncorrectFilename(testCase) 

end

function test_AllWords(testCase) 

end

function test_MaxFreq(testCase) 

end

function teardownOnce(testCase)

end