function tests = test_strdist

tests = functiontests( localfunctions() );

end

function setupOnce(testCase) %#ok<*DEFNU>

end

function test_OneWord(testCase) 

end

function test_ThreeWords(testCase) 

end

function test_DimensionsOutput(testCase) 

end

function teardownOnce(testCase)

end